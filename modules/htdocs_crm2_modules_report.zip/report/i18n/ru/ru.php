<?php

return array
(
	'sn'=>'№ п/п',
	'YEARFROM'=>'Год',
	'MONTFROM'=>'Месяц',
	'COUNT'=>'Количество',
	'mreport.stat'=>'Тест',
	'mreport.report1'=>'Отчет регистрация контактов',
	'button.makeReport'=>'Подготовить отчет',
	'fromUser'=>'Отчет подготовил',
	'depatment'=>'Подразделение',
	'dateCreated'=>'Дата подготовки отчета',
	'mreport.history'=> 'Отчет журнал событий',
	'mreport.allcontact'=> 'Список всех контактов',
	'contact.allContactsExport'=> 'Просмотр и экспорт контактов',
	'button.allContactsExport'=> 'Подготовить отчет Просмотр и экспорт контактов',
  
);